enum class Flavor {
    SWEET, SAVORY
}

data class Recipe(
    val id: Long = System.currentTimeMillis(),
    val title: String,
    val description: String,
    val flavor: Flavor
)

sealed class ListItem {
    data class FlavorTitle(val flavor: Flavor) : ListItem()
    data class RecipeItem(val recipe: Recipe) : ListItem()
}